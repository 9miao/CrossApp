//
//  umSDK.cpp
//  HelloCpp
//
//  Created by 栗元峰 on 14-11-14.
//
//

#include "../umSDK.h"

namespace umSDK
{
    void startWithAppkey(const char* appkey, const char* channel)
    {
    
    }
    
    void onPageStart(const char* ViewID)
    {
        
    }
    
    void onPageEnd(const char* ViewID)
    {
        
    }
    
    void onEventBegin(const char* eventId)
    {
        
    }
    
    void onEventBeginValue(const char* eventId, const char* value)
    {
        
    }
    
    void onEventEnd(const char* eventId)
    {
        
    }
    
    void onEventEndValue(const char* eventId, const char* value)
    {
        
    }
    
    void onEvent(const char* eventId)
    {
        
    }
    
    void onEventValue(const char* eventId, const char* value)
    {
        
    }
    
    void onEventMap(const char* eventId, const std::map<std::string,std::string>& map)
    {
        
    }
    
    void onEventMapValue(const char* eventId, const std::map<std::string,std::string>& map, int value)
    {
        
    }
};